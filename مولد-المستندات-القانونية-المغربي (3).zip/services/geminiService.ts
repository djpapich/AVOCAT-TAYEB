import { GoogleGenAI, Type } from "@google/genai";
import { FormData, DocumentType, ClientData, CaseData } from '../types';

// Static data for the specific lawyer
const LAWYER_DATA = {
  name: 'الأستاذ الطيب محمد',
  bar: 'هيئة المحامين بالرباط',
  address: '123 شارع الحرية، الرباط',
  cin: 'A123456'
};

const getLegalFramework = (docType: DocumentType): string => {
    switch (docType) {
        case DocumentType.FeeAgreement:
            return "القانون المنظم لمهنة المحاماة والنظام الداخلي الموحد لهيئة المحامين بالمغرب (خاصة المادة 27).";
        case DocumentType.AdminPowerOfAttorney:
            return "قانون الالتزامات والعقود المغربي (خاصة الفصول 879 إلى 913) و ظهير 12 غشت 1913 المتعلق بالتحفيظ العقاري.";
        case DocumentType.JudicialPowerOfAttorney:
            return "قانون المسطرة المدنية المغربي (خاصة الفصول 32 إلى 39).";
        case DocumentType.GeneralPowerOfAttorney:
            return "قانون الالتزامات والعقود المغربي (خاصة الفصول 879 إلى 913).";
        case DocumentType.IncidentalRequest:
            return "قانون المسطرة المدنية المغربي والنموذج المعتمد في منصة عدالة.";
        default:
            return "القانون المغربي المعمول به.";
    }
}

// Helper function to convert file to base64
const fileToGenerativePart = async (file: File) => {
  const base64EncodedDataPromise = new Promise<string>((resolve) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve((reader.result as string).split(',')[1]);
    reader.readAsDataURL(file);
  });
  return {
    inlineData: { data: await base64EncodedDataPromise, mimeType: file.type },
  };
};


export const extractDataFromDocument = async (file: File): Promise<FormData> => {
    if (!process.env.API_KEY) {
        throw new Error("API_KEY environment variable not set");
    }
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const model = 'gemini-2.5-flash';

    const filePart = await fileToGenerativePart(file);

    const prompt = `
    Analyze the provided document (which could be an ID card, contract, property title, etc.) and extract the following information into a valid JSON object.
    
    - Client's full name (fullName)
    - Client's date of birth (dob)
    - Client's National Identity Card number (cin)
    - Client's address (address)
    - Client's bank account (bankAccount)
    - The type of case or legal matter (type)
    - Specific references like property title numbers, case numbers, etc. (references)
    - Fee amount (fees)
    - Advance payment amount (advance)
    - Associated costs (costs)

    If any piece of information is not present in the document, return an empty string "" for that field. Do not invent or infer data.
    Return ONLY the JSON object.
    `;

    const response = await ai.models.generateContent({
        model: model,
        contents: { parts: [filePart, { text: prompt }] },
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    client: {
                        type: Type.OBJECT,
                        properties: {
                            fullName: { type: Type.STRING },
                            dob: { type: Type.STRING },
                            cin: { type: Type.STRING },
                            address: { type: Type.STRING },
                            bankAccount: { type: Type.STRING },
                        }
                    },
                    case: {
                        type: Type.OBJECT,
                        properties: {
                            type: { type: Type.STRING },
                            references: { type: Type.STRING },
                            fees: { type: Type.STRING },
                            advance: { type: Type.STRING },
                            costs: { type: Type.STRING },
                        }
                    }
                }
            }
        }
    });
    
    const jsonString = response.text.trim();
    const parsedJson = JSON.parse(jsonString);
    
    // Ensure the structure matches FormData, even if Gemini returns a slightly different shape.
    return {
      client: parsedJson.client || {},
      case: parsedJson.case || {},
    };
};


const generatePrompt = (formData: { client: Partial<ClientData>, case: Partial<CaseData> }, docType: DocumentType): string => {
    const fullData = {
        lawyer: LAWYER_DATA,
        client: formData.client,
        case: formData.case
    };

    return `
    Act as an expert Moroccan lawyer, Tayeb Mohamed, specializing in legal document drafting. Your task is to generate an official legal document in Arabic, formatted as clean HTML, ready to be printed.

    **Document Type to Generate:** ${docType}

    **Applicable Legal Framework:** Adhere strictly to the Moroccan legal framework: ${getLegalFramework(docType)}. You can include references to the relevant articles within the document where appropriate.

    **Input Data (in JSON format):**
    ${JSON.stringify(fullData, null, 2)}

    **Formatting and Content Instructions (VERY IMPORTANT):**
    1.  **Output Format:** The entire output must be a single block of clean, semantic HTML code. Do NOT include \`\`\`html, markdown, explanations, or any text outside the final HTML structure. The output should be ready to be injected directly into a \`<div>\`. Do NOT include \`<html>\`, \`<head>\`, or \`<body>\` tags.
    2.  **Language:** The entire text must be in formal, legal Arabic.
    3.  **Data Integration:** Seamlessly and accurately integrate the provided JSON data into the document.
    4.  **Structure:** Follow the official and customary structure for this type of document in Morocco. It must look professional and official.
    5.  **Placeholders:** Include clear, standard placeholders for signatures, dates, and legalization. For example:
        -   For the date and location: \`حرر بـ ______________ بتاريخ ______________\`
        -   For signatures: \`إمضاء المحامي:                  إمضاء الموكل:\`
    6.  **Official Tone:** The tone must be formal, authoritative, and legally sound, reflecting the identity of الأستاذ الطيب محمد.
    7.  **Paragraphs and Spacing:** Use \`<p>\` tags for paragraphs and ensure proper spacing for readability. Use \`<h2>\` or \`<h3>\` for titles and subtitles.
    8.  **Example Title:** For a fee agreement, the main title could be \`<h2>اتفاقية أتعاب</h2>\`.
    9. **No Logo:** Do not include the Kingdom of Morocco logo; it will be added by the UI.

    Generate the complete HTML for the document now based on these instructions.
    `;
}

export const generateDocument = async (formData: { client: Partial<ClientData>, case: Partial<CaseData> }, docType: DocumentType): Promise<string> => {
    if (!process.env.API_KEY) {
        throw new Error("API_KEY environment variable not set");
    }

    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const model = 'gemini-2.5-flash';
    
    const prompt = generatePrompt(formData, docType);

    try {
        const response = await ai.models.generateContent({
            model: model,
            contents: prompt,
        });
        
        const htmlContent = response.text.trim().replace(/```html/g, '').replace(/```/g, '');
        return htmlContent;
    } catch (error) {
        console.error("Error calling Gemini API:", error);
        throw new Error("Failed to generate document from Gemini API.");
    }
};
