import React from 'react';

interface Props {
  steps: string[];
  currentStep: number;
}

const Stepper: React.FC<Props> = ({ steps, currentStep }) => {
  return (
    <div className="w-full max-w-4xl mx-auto px-4 sm:px-0">
      <div className="flex items-center">
        {steps.map((step, index) => (
          <React.Fragment key={step}>
            <div className="flex items-center text-teal-600 relative">
              <div
                className={`rounded-full transition duration-500 ease-in-out h-12 w-12 flex items-center justify-center py-3 border-2 ${
                  index <= currentStep ? 'bg-teal-600 border-teal-600 text-white' : 'border-gray-300 text-gray-500 bg-white'
                }`}
              >
                <span className="font-bold text-lg">{index + 1}</span>
              </div>
              <div className={`absolute top-0 -ml-10 text-center mt-16 w-32 text-xs font-medium uppercase ${
                  index <= currentStep ? 'text-teal-600' : 'text-gray-500'
                }`}>{step}</div>
            </div>
            {index < steps.length - 1 && (
              <div className={`flex-auto border-t-2 transition duration-500 ease-in-out ${
                index < currentStep ? 'border-teal-600' : 'border-gray-300'
              }`}></div>
            )}
          </React.Fragment>
        ))}
      </div>
    </div>
  );
};

export default Stepper;
