import React from 'react';
import { DocumentType } from '../types';

interface Props {
  onSelect: (docTypes: DocumentType[]) => void;
}

const FeeAgreementIcon: React.FC<{className: string}> = ({ className }) => (<svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}><path strokeLinecap="round" strokeLinejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m5.231 13.481L15 17.25m-4.5-1.5l-2.625 2.625a3.375 3.375 0 004.773 4.773l2.625-2.625m2.121-9.061l-2.625 2.625m2.121-9.061a3.375 3.375 0 00-4.773-4.773L9.75 5.25m2.121 9.061a3.375 3.375 0 01-4.773 4.773l-2.625-2.625m-1.5-4.5l2.625 2.625" /></svg>);
const AdminIcon: React.FC<{className: string}> = ({ className }) => (<svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}><path strokeLinecap="round" strokeLinejoin="round" d="M2.25 21h19.5m-18-18v18m10.5-18v18m6-13.5V21M6.75 6.75h.75m-.75 3h.75m-.75 3h.75m3-6h.75m-.75 3h.75m-.75 3h.75M9 21v-3.375c0-.621.504-1.125 1.125-1.125h3.75c.621 0 1.125.504 1.125 1.125V21" /></svg>);
const JudicialIcon: React.FC<{className: string}> = ({ className }) => (<svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}><path strokeLinecap="round" strokeLinejoin="round" d="M3.75 21h16.5M4.5 3h15M5.25 3v18m13.5-18v18M9 6.75h6M9 11.25h6m-6 4.5h6M6.75 21v-2.25a2.25 2.25 0 012.25-2.25h6a2.25 2.25 0 012.25 2.25V21" /></svg>);
const GeneralIcon: React.FC<{className: string}> = ({ className }) => (<svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}><path strokeLinecap="round" strokeLinejoin="round" d="M15.75 6a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0zM4.501 20.118a7.5 7.5 0 0114.998 0A17.933 17.933 0 0112 21.75c-2.676 0-5.216-.584-7.499-1.632z" /><path strokeLinecap="round" strokeLinejoin="round" d="M12 12.75a2.25 2.25 0 100-4.5 2.25 2.25 0 000 4.5z" /><path strokeLinecap="round" strokeLinejoin="round" d="M3.863 10.922c.28.357.484.75.635 1.172a.375.375 0 01-.71.254 9.348 9.348 0 00-.345-1.426c-.053-.218.056-.442.232-.533a.375.375 0 01.533.232z" /><path strokeLinecap="round" strokeLinejoin="round" d="M20.137 10.922c-.28.357-.484.75-.635 1.172a.375.375 0 00.71.254 9.348 9.348 0 01.345-1.426c.053-.218-.056-.442-.232-.533a.375.375 0 00-.533.232z" /><path strokeLinecap="round" strokeLinejoin="round" d="M6.906 14.825c.224.38.484.733.778 1.055a.375.375 0 01-.546.51 9.348 9.348 0 00-1.042-1.254.375.375 0 01.465-.602.375.375 0 01.345.291z" /><path strokeLinecap="round" strokeLinejoin="round" d="M17.094 14.825c-.224.38-.484.733-.778 1.055a.375.375 0 00.546.51 9.348 9.348 0 011.042-1.254.375.375 0 00-.465-.602.375.375 0 00-.345.291z" /></svg>);
const RequestIcon: React.FC<{className: string}> = ({ className }) => (<svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}><path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>);

const documentIcons: Record<DocumentType, React.ElementType> = {
    [DocumentType.FeeAgreement]: FeeAgreementIcon,
    [DocumentType.AdminPowerOfAttorney]: AdminIcon,
    [DocumentType.JudicialPowerOfAttorney]: JudicialIcon,
    [DocumentType.GeneralPowerOfAttorney]: GeneralIcon,
    [DocumentType.IncidentalRequest]: RequestIcon,
};

const DocumentButton: React.FC<{ docType: DocumentType; onSelect: () => void; Icon: React.ElementType;}> = ({ docType, onSelect, Icon }) => (
    <button onClick={onSelect} className="group flex flex-col items-center justify-center p-6 bg-white rounded-lg shadow-md hover:shadow-xl hover:bg-teal-50 border-2 border-transparent hover:border-teal-500 transition-all duration-300 transform hover:-translate-y-1">
        <Icon className="w-12 h-12 text-teal-600 mb-4 transition-transform duration-300 group-hover:scale-110" />
        <span className="text-center font-semibold text-gray-700">{docType}</span>
    </button>
);

const DocumentSelector: React.FC<Props> = ({ onSelect }) => {
    const documentTypes = Object.values(DocumentType);

    const handleBatchGenerate = () => {
        onSelect([
            DocumentType.FeeAgreement,
            DocumentType.JudicialPowerOfAttorney,
            DocumentType.AdminPowerOfAttorney,
        ]);
    };

    return (
        <div className="bg-white p-8 rounded-lg shadow-xl max-w-5xl mx-auto text-center">
            <h2 className="text-3xl font-bold text-gray-800 mb-2">الخطوة 1: اختيار نوع المستند</h2>
            <p className="text-gray-600 mb-8">اختر مستندًا فرديًا أو قم بإنشاء حزمة المستندات الأكثر شيوعًا بنقرة واحدة.</p>
            
            <div className="mb-8 p-6 bg-teal-50 border-2 border-teal-200 rounded-lg">
                 <button onClick={handleBatchGenerate} className="group w-full flex items-center justify-center text-teal-800 hover:text-teal-900 transition">
                     <svg xmlns="http://www.w3.org/2000/svg" className="w-10 h-10 mr-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}><path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12a7.5 7.5 0 0015 0m-15 0a7.5 7.5 0 1115 0m-15 0H3m16.5 0H21m-1.5 0A2.25 2.25 0 0018 9.75V9A2.25 2.25 0 0015.75 6.75h-7.5A2.25 2.25 0 006 9v.75a2.25 2.25 0 001.5 2.25M12 12.75V15m0 0V12.75m0 2.25H9.75m2.25 0H14.25" /></svg>
                     <div>
                         <span className="text-xl font-bold">إنشاء الحزمة الشائعة</span>
                         <p className="text-sm">(اتفاقية أتعاب + وكالة قضائية + وكالة إدارية)</p>
                     </div>
                 </button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6">
                {documentTypes.map(docType => (
                    <DocumentButton key={docType} docType={docType} onSelect={() => onSelect([docType])} Icon={documentIcons[docType]} />
                ))}
            </div>
        </div>
    );
};

export default DocumentSelector;
