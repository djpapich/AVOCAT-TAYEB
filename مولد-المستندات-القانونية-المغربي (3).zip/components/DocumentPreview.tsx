import React, { useRef, useState } from 'react';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import saveAs from 'file-saver';
import { GeneratedDocument } from '../types';

interface Props {
  generatedDocuments: GeneratedDocument[];
  onBack: () => void;
  onReset: () => void;
}

const MoroccoLogo = () => (
  <div className="flex justify-center mb-8">
    <img
      src="https://www.maroc.ma/sites/default/files/logo-maroc.png"
      alt="شعار المملكة المغربية"
      style={{ width: '113px' }}
    />
  </div>
);

const DocumentPreview: React.FC<Props> = ({ generatedDocuments, onBack, onReset }) => {
  const previewRef = useRef<HTMLDivElement>(null);
  const [activeDocIndex, setActiveDocIndex] = useState(0);
  const [addWatermark, setAddWatermark] = useState(true);

  if (generatedDocuments.length === 0) {
    return (
        <div className="text-center p-8 bg-white rounded-lg shadow-xl">
            <h2 className="text-2xl font-bold">لم يتم إنشاء أي مستند</h2>
            <p className="text-gray-600 my-4">حدث خطأ ما أو لم يتم تحديد أي مستند.</p>
            <button onClick={onBack} className="bg-gray-500 hover:bg-gray-600 text-white font-bold py-2 px-6 rounded-lg">
                العودة
            </button>
        </div>
    );
  }

  const activeDocument = generatedDocuments[activeDocIndex];
  const { docType, htmlContent } = activeDocument;

  const downloadPdf = async () => {
    const element = previewRef.current;
    if (!element) return;
    
    const canvas = await html2canvas(element, { scale: 2, useCORS: true });
    
    const imgData = canvas.toDataURL('image/png');
    const pdf = new jsPDF('p', 'mm', 'a4');
    const pdfWidth = pdf.internal.pageSize.getWidth();
    const imgProps= pdf.getImageProperties(imgData);
    const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
    
    let heightLeft = pdfHeight;
    let position = 0;

    pdf.addImage(imgData, 'PNG', 0, position, pdfWidth, pdfHeight);
    heightLeft -= pdf.internal.pageSize.getHeight();

    while (heightLeft > 0) {
      position = heightLeft - pdfHeight;
      pdf.addPage();
      pdf.addImage(imgData, 'PNG', 0, position, pdfWidth, pdfHeight);
      heightLeft -= pdf.internal.pageSize.getHeight();
    }
    
    pdf.save(`${docType}.pdf`);
  };

  const downloadDocx = async () => {
    if(!docType) return;
    
    const header = `<html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'><head><meta charset='utf-8'><title>Export HTML to Word Document</title><style>body {font-family: 'Amiri', serif; direction: rtl;} @page { size: A4; margin: 3cm 2cm 2cm 2cm; } </style></head><body>`;
    const footer = "</body></html>";
    // Cloning the node to avoid manipulating the live DOM for the logo
    const contentNode = document.getElementById('document-content')?.cloneNode(true) as HTMLElement;
    const logoImg = `<div style="text-align: center;"><img src="https://www.maroc.ma/sites/default/files/logo-maroc.png" alt="Logo" width="113" /></div>`;
    const sourceHTML = header + logoImg + contentNode.innerHTML + footer;
    
    const blob = new Blob([sourceHTML], { type: 'application/vnd.ms-word' });
    saveAs(blob, `${docType}.doc`);
  };


  return (
    <div className="max-w-5xl mx-auto">
        <div className="bg-white p-4 rounded-t-lg shadow-lg flex justify-between items-center flex-wrap gap-4">
            <div>
                <h2 className="text-3xl font-bold text-gray-800">الخطوة 4: معاينة وتصدير</h2>
                <p className="text-gray-600">المستند(ات) جاهزة. قم بالتنزيل أو ابدأ من جديد.</p>
            </div>
            <div className="flex items-center gap-x-2 flex-wrap">
                 <button onClick={downloadDocx} className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-lg transition text-sm">تحميل Word</button>
                 <button onClick={downloadPdf} className="bg-teal-600 hover:bg-teal-700 text-white font-bold py-2 px-4 rounded-lg transition text-sm">تحميل PDF</button>
                 <button onClick={onBack} className="bg-gray-500 hover:bg-gray-600 text-white font-bold py-2 px-4 rounded-lg transition text-sm">العودة</button>
                 <button onClick={onReset} className="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded-lg transition text-sm">البدء من جديد</button>
            </div>
        </div>
        
        <div className="bg-gray-200 p-2 flex items-center justify-between flex-wrap">
            <div className="flex border-b-0">
                {generatedDocuments.map((doc, index) => (
                    <button 
                        key={doc.docType} 
                        onClick={() => setActiveDocIndex(index)}
                        className={`py-2 px-4 text-sm font-medium transition ${activeDocIndex === index ? 'bg-white text-teal-700 shadow rounded-t-md' : 'text-gray-600 hover:bg-gray-300'}`}
                    >
                        {doc.docType}
                    </button>
                ))}
            </div>
            <div className="flex items-center gap-x-2 p-2">
                <input type="checkbox" id="watermark-checkbox" checked={addWatermark} onChange={(e) => setAddWatermark(e.target.checked)} className="h-4 w-4 rounded border-gray-300 text-teal-600 focus:ring-teal-500" />
                <label htmlFor="watermark-checkbox" className="text-sm text-gray-700">إضافة علامة "مسودة"</label>
            </div>
        </div>

      <div
        ref={previewRef}
        id="document-preview"
        className="relative bg-white p-12 shadow-lg leading-loose overflow-hidden"
        style={{ width: '210mm', minHeight: '297mm', margin: '0 auto' }}
      >
        {addWatermark && (
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-10">
                <span className="text-8xl md:text-9xl font-black text-gray-300 opacity-50 transform -rotate-45 select-none" style={{letterSpacing: '0.2em'}}>
                    مسودة
                </span>
            </div>
        )}
        <div className="relative z-0">
            <MoroccoLogo />
            <div id="document-content" dangerouslySetInnerHTML={{ __html: htmlContent }} />
        </div>
      </div>
    </div>
  );
};

export default DocumentPreview;
