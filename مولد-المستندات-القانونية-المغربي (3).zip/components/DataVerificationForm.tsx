import React, { useState, useEffect } from 'react';
import { FormData } from '../types';

interface Props {
  onSubmit: (data: FormData) => void;
  initialData: FormData | null;
  onBack: () => void;
}

const SectionTitle: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <h2 className="text-2xl font-bold text-gray-700 border-b-2 border-teal-500 pb-2 mb-6">{children}</h2>
);

const InputField: React.FC<{ label: string; name: string; value: string; onChange: (e: React.ChangeEvent<HTMLInputElement>) => void; required?: boolean; isMissing: boolean; }> = ({ label, name, value, onChange, required = true, isMissing }) => (
  <div className="mb-4">
    <label htmlFor={name} className="block text-gray-700 text-sm font-bold mb-2">{label}{required && <span className="text-red-500">*</span>}</label>
    <input
      type="text"
      id={name}
      name={name}
      value={value}
      onChange={onChange}
      required={required}
      className={`shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline focus:ring-2 transition ${isMissing && required ? 'border-red-500 focus:ring-red-500' : 'focus:ring-teal-500'}`}
    />
    {isMissing && required && <p className="text-red-500 text-xs italic mt-1">هذا الحقل مطلوب.</p>}
  </div>
);

const TextAreaField: React.FC<{ label: string; name: string; value: string; onChange: (e: React.ChangeEvent<HTMLTextAreaElement>) => void; required?: boolean; isMissing: boolean; }> = ({ label, name, value, onChange, required = true, isMissing }) => (
  <div className="mb-4">
    <label htmlFor={name} className="block text-gray-700 text-sm font-bold mb-2">{label}{required && <span className="text-red-500">*</span>}</label>
    <textarea
      id={name}
      name={name}
      value={value}
      onChange={onChange}
      required={required}
      rows={4}
      className={`shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline focus:ring-2 transition ${isMissing && required ? 'border-red-500 focus:ring-red-500' : 'focus:ring-teal-500'}`}
    />
    {isMissing && required && <p className="text-red-500 text-xs italic mt-1">هذا الحقل مطلوب.</p>}
  </div>
);

const DataVerificationForm: React.FC<Props> = ({ onSubmit, initialData, onBack }) => {
  const [formData, setFormData] = useState<FormData>({
    client: { fullName: '', dob: '', cin: '', address: '', bankAccount: '' },
    case: { type: '', references: '', fees: '', advance: '', costs: '' }
  });

  useEffect(() => {
    if (initialData) {
        // Merge initial data with default structure to prevent undefined errors
        setFormData({
            client: { ...formData.client, ...initialData.client },
            case: { ...formData.case, ...initialData.case }
        });
    }
  }, [initialData]);

  const handleChange = (section: keyof FormData, e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [section]: {
        ...prev[section],
        [name]: value
      }
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };
  
  const isClientFieldMissing = (fieldName: keyof FormData['client']) => !formData.client[fieldName];
  const isCaseFieldMissing = (fieldName: keyof FormData['case']) => !formData.case[fieldName];

  return (
    <div className="bg-white p-8 rounded-lg shadow-xl max-w-4xl mx-auto">
      <h2 className="text-3xl font-bold text-gray-800 mb-2">الخطوة 3: مراجعة وإكمال البيانات</h2>
      <p className="text-gray-600 mb-8">
        لقد قمنا باستخلاص البيانات التالية من المستند. يرجى مراجعتها وتعبئة الحقول الفارغة المطلوبة (<span className="text-red-500">*</span>).
      </p>
      <form onSubmit={handleSubmit}>
        
        <SectionTitle>معلومات الموكل (الزبون)</SectionTitle>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6">
          <InputField label="الاسم الكامل" name="fullName" value={formData.client.fullName || ''} onChange={(e) => handleChange('client', e)} isMissing={isClientFieldMissing('fullName')} />
          <InputField label="بطاقة التعريف الوطنية" name="cin" value={formData.client.cin || ''} onChange={(e) => handleChange('client', e)} isMissing={isClientFieldMissing('cin')} />
          <InputField label="تاريخ الازدياد" name="dob" value={formData.client.dob || ''} onChange={(e) => handleChange('client', e)} required={false} isMissing={false} />
          <InputField label="العنوان البريدي" name="address" value={formData.client.address || ''} onChange={(e) => handleChange('client', e)} required={false} isMissing={false}/>
          <InputField label="الحساب البنكي (إذا كان ذا صلة)" name="bankAccount" value={formData.client.bankAccount || ''} onChange={(e) => handleChange('client', e)} required={false} isMissing={false} />
        </div>

        <SectionTitle>معطيات القضية / الملف</SectionTitle>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6">
            <InputField label="نوع الملف (مثال: نزاع عقاري)" name="type" value={formData.case.type || ''} onChange={(e) => handleChange('case', e)} isMissing={isCaseFieldMissing('type')} />
            <InputField label="مبلغ الأتعاب" name="fees" value={formData.case.fees || ''} onChange={(e) => handleChange('case', e)} isMissing={isCaseFieldMissing('fees')} />
            <InputField label="مبلغ التسبيق" name="advance" value={formData.case.advance || ''} onChange={(e) => handleChange('case', e)} isMissing={isCaseFieldMissing('advance')} />
            <InputField label="المصاريف" name="costs" value={formData.case.costs || ''} onChange={(e) => handleChange('case', e)} required={false} isMissing={false}/>
        </div>
        <TextAreaField label="مراجع دقيقة (رسم عقاري، أرقام قطع، إلخ)" name="references" value={formData.case.references || ''} onChange={(e) => handleChange('case', e)} isMissing={isCaseFieldMissing('references')}/>

        <div className="mt-8 flex justify-between items-center">
            <button type="button" onClick={onBack} className="bg-gray-500 hover:bg-gray-600 text-white font-bold py-2 px-6 rounded-lg transition">
                العودة
            </button>
            <button
                type="submit"
                className="bg-teal-600 hover:bg-teal-700 text-white font-bold py-3 px-12 rounded-lg focus:outline-none focus:shadow-outline transition transform hover:scale-105"
            >
                التالي: إنشاء المستند النهائي
            </button>
        </div>
      </form>
    </div>
  );
};

export default DataVerificationForm;
