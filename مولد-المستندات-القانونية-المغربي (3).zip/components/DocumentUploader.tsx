import React, { useState, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';

interface Props {
  onSubmit: (file: File) => void;
  onBack: () => void;
}

const DocumentUploader: React.FC<Props> = ({ onSubmit, onBack }) => {
  const [file, setFile] = useState<File | null>(null);
  const [error, setError] = useState<string | null>(null);

  const onDrop = useCallback((acceptedFiles: File[], rejectedFiles: any[]) => {
    if (rejectedFiles.length > 0) {
      setError('يرجى تحميل ملف PDF أو Word صالح.');
      setFile(null);
      return;
    }
    if (acceptedFiles.length > 0) {
      setFile(acceptedFiles[0]);
      setError(null);
    }
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
        'application/pdf': ['.pdf'],
        'application/msword': ['.doc'],
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx'],
    },
    multiple: false,
  });

  const handleSubmit = () => {
    if (file) {
      onSubmit(file);
    } else {
      setError('الرجاء اختيار ملف أولاً.');
    }
  };

  return (
    <div className="bg-white p-8 rounded-lg shadow-xl max-w-2xl mx-auto text-center">
      <h2 className="text-3xl font-bold text-gray-800 mb-2">الخطوة 2: تحميل المستند المصدر</h2>
      <p className="text-gray-600 mb-8">
        قم برفع ملف (PDF, DOCX, DOC) مثل بطاقة تعريف، عقد، أو رسم عقاري. سيقوم النظام الذكي باستخلاص البيانات منه.
      </p>

      <div
        {...getRootProps()}
        className={`p-10 border-4 border-dashed rounded-lg cursor-pointer transition-colors
          ${isDragActive ? 'border-teal-500 bg-teal-50' : 'border-gray-300 hover:border-teal-400'}`}
      >
        <input {...getInputProps()} />
        <svg className="mx-auto h-12 w-12 text-gray-400" stroke="currentColor" fill="none" viewBox="0 0 48 48" aria-hidden="true">
            <path d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
        {isDragActive ? (
          <p className="mt-2 text-lg font-semibold text-teal-700">أفلت الملف هنا...</p>
        ) : (
          <p className="mt-2 text-gray-600">اسحب وأفلت الملف هنا، أو انقر للاختيار</p>
        )}
      </div>

      {file && (
        <div className="mt-6 text-center bg-gray-100 p-4 rounded-lg">
          <p className="font-semibold text-gray-800">الملف المختار:</p>
          <p className="text-teal-600">{file.name}</p>
        </div>
      )}
      
      {error && <p className="text-red-500 mt-4">{error}</p>}
      
      <div className="mt-8 flex justify-between items-center">
        <button onClick={onBack} className="bg-gray-500 hover:bg-gray-600 text-white font-bold py-2 px-6 rounded-lg transition">
            العودة
        </button>
        <button
          onClick={handleSubmit}
          disabled={!file}
          className="bg-teal-600 hover:bg-teal-700 text-white font-bold py-3 px-8 rounded-lg focus:outline-none focus:shadow-outline transition transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          تحليل المستند والمتابعة
        </button>
      </div>
    </div>
  );
};

export default DocumentUploader;
