
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-white mt-12 py-4 shadow-inner">
      <div className="container mx-auto px-8 text-center text-gray-500">
        <p>
          &copy; {new Date().getFullYear()} مولد المستندات القانونية. تطبيق تجريبي تم إنشاؤه بواسطة مهندس برمجيات خبير.
        </p>
         <p className="text-xs mt-1">« تطبيق مغربي، من قبل المحامين ولأجلهم، يحول ملفاتكم إلى وثائق رسمية، جاهزة للتوقيع في أقل من 60 ثانية. »</p>
      </div>
    </footer>
  );
};

export default Footer;
